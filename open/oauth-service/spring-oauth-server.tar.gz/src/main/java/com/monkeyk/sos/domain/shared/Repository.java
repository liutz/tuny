package com.monkeyk.sos.domain.shared;

/**
 * @author Shengzhao Li
 */

public interface Repository {
}