package com.monkeyk.sos.domain.user;

/**
 * @author Shengzhao Li
 */
public enum Privilege {

    USER,          //Default privilege

    UNITY,
    MOBILE
}